# data/urls.py

MAIN_PAGE_URL = "https://qa-scooter.praktikum-services.ru/"