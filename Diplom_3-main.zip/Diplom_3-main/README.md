# Diplom_3
