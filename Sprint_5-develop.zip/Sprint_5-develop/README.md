# Sprint_5
Автоматизация тестирования для Stellar Burgers.

## Установка
1. Установите зависимости: `pip install -r requirements.txt`
2. Запустите тесты: `pytest tests/`